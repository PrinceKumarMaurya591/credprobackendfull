package com.au.credpro.report;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CredProReportApplicationTests {

	@Test
	void contextLoads() {
	}

}
